
export const NO_BUTTON_PHRASES: string[] = [
  "No",
  "Sigurado ka na ba?",
  "Siguradong Sigurado ka na nga ?",
  "Pag isipan mo ulit mabuti!",
  "Bigyan pa kita isa pang pagkakataon!",
  "Sure ka na nga",
  "Baka pag sisihan mo",
  "try mo lang ulit",
  "Sure na sure na nga?",
  "Baka mali kalang ng napili",
  "Please say yes!",
  "Don't be so cold!",
  "yes na magbabago pa yan",
  "Baka pwede mo pa maconsider yung yes",
  "Final Answer na ba talaga yan ?",
  "You're breaking my heart ;(",
];

export const GIFS = {
    INITIAL: "https://media.tenor.com/p0WL4ZA2WNUAAAAj/peach-goma-peach-and-goma.gif",
    SAD: "https://media.tenor.com/PAyE85Ez53oAAAAj/mochi-mochimochi.gif",
    SUCCESS: "https://media.tenor.com/ivKWdfdbV3EAAAAj/goma-goma-cat.gif"
};
